# Task 1 — Document 01: Problem Statement Understanding

> **Problem Statement ID:** PS 26117 / SIH26117  
> **Title:** Sovereign On-Premise Agentic AI Workbench using Open-Weight Multimodal LLMs for Confidential Industrial Work  
> **Organization:** Mangalore Refinery and Petrochemicals Limited (MRPL)  
> **Category:** Software | **Theme:** Smart Automation  

---

## 1. Executive Context & Problem Background

**Mangalore Refinery and Petrochemicals Limited (MRPL)** is a premier Miniratna Central Public Sector Enterprise operating complex crude oil refining facilities. Industrial refining operations rely heavily on thousands of confidential Standard Operating Procedures (SOPs), technical manuals, piping & instrumentation diagrams (P&IDs), daily equipment inspection logs, emergency shutdown protocols, and regulatory compliance documents.

In modern industrial facilities, plant engineers and technical staff spend significant hours searching through vast repositories of structured and unstructured documents to answer operational questions, verify safety protocols, or debug equipment issues (e.g., pump vibration anomalies, valve maintenance).

---

## 2. Core Industrial Pain Points & Challenges

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CRITICAL INDUSTRIAL PAIN POINTS                 │
├──────────────────────────────────┬─────────────────────────────────────┤
│ 🔒 1. Confidentiality & Air-Gap   │ Cloud AI models (ChatGPT, Claude)   │
│    Data Leakage Risks            │ expose sensitive IP & SOP secrets.  │
├──────────────────────────────────┼─────────────────────────────────────┤
│ 📄 2. Multimodal Unstructured    │ Equipment manuals & inspection logs │
│    Data Overload                 │ exist as scanned PDFs & images.     │
├──────────────────────────────────┼─────────────────────────────────────┤
│ ❌ 3. AI Hallucination Risks     │ Inaccurate operational guidance     │
│                                  │ risks severe plant safety hazards.  │
├──────────────────────────────────┼─────────────────────────────────────┤
│ ⏳ 4. Search Latency & Downtime  │ Engineers waste hours manually      │
│    in Critical Incidents         │ cross-referencing paper SOPs.       │
└──────────────────────────────────┴─────────────────────────────────────┘
```

### Key Challenges in Detail:

1. **Air-Gap & Confidentiality Constraints**:
   - Refineries operate under strict cybersecurity protocols (ISO 27001 / Critical Infrastructure directives).
   - Sending proprietary operational data, refinery diagrams, or maintenance records to third-party public cloud AI APIs poses severe security risks, legal non-compliance, and industrial espionage vulnerabilities.

2. **Multimodal Document Processing Overhead**:
   - Industrial knowledge is non-standardized. A single pump inspection task involves typed PDFs, scanned handwritten maintenance logs, blueprint diagrams, and digital text reports.
   - Traditional keyword search fails on scanned documents, diagrams, and unstructured image logs.

3. **Hallucination Zero-Tolerance in Industrial Safety**:
   - General-purpose public AI chatbots frequently generate plausible-sounding but inaccurate answers (hallucinations).
   - In a petrochemical refinery, an inaccurate pressure limit or incorrect shutdown sequence can cause catastrophic equipment failure or safety hazards. Answers must be strictly grounded in verified internal documentation with exact source attribution.

4. **Multi-Task Technical Requirements**:
   - Engineers require varied tasks: retrieving SOP steps, extracting tabular inspection values from images, writing automation/maintenance scripts, and generating formal inspection notes.

---

## 3. Problem Statement Objectives & Scope

### Primary Objective
To design and implement a **Sovereign, On-Premise, Agentic AI Workbench** that operates 100% offline within MRPL's local network infrastructure. The workbench empowers engineers to interact with confidential multimodal documents, query grounded knowledge bases, perform OCR text extraction from images, and generate technical code—**with zero cloud dependency or telemetry**.

### In-Scope Deliverables
- **100% Local Inference Engine**: Running open-weight quantized models (`qwen3.5:4b`, `qwen2.5-coder:7b`, `glm-ocr:q8_0`, `nomic-embed-text`) via Ollama.
- **Local Multimodal Retrieval-Augmented Generation (RAG)**: Indexing PDFs, text documents, and scanned image text into a local vector store.
- **Strict Anti-Hallucination Guardrails**: Fallback mechanisms ("Information not available in knowledge base") when query context is absent.
- **Dedicated Task Routing**: Intelligent dispatch between general reasoning, grounded document search, specialized coding, and image OCR pipelines.
- **Air-Gapped Responsive Web UI**: Modern dark-themed interface for document upload, knowledge toggling, and interactive chat.

### Out-of-Scope (for Initial Phase)
- External cloud API fallback or cloud sync.
- Production multi-node distributed GPU cluster setup (focused on single-node on-premise workstation/server deployment).
